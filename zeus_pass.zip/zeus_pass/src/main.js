const Samudragansmand = require('./command');
const { Message, OpType, Location, Profile } = require('../curve-thrift/line_types');

class LINE extends Samudragansmand {
    constructor() {
        super();
        this.receiverID = '';
        this.messages;
        this.payload;
    }


    get myBot() {
        const bot = ['',''];
        return bot;
    }

    isAdminOrBot(param) {
        return this.myBot.includes(param);
    }

    getOprationType(operations) {
        for (let key in OpType) {
            if(operations.type == OpType[key]) {
                if(key !== 'NOTIFIED_UPDATE_PROFILE') {
                    console.info(`[# ${operations.type} ] ${key} `);
                }
            }
        }
    }

    poll(operation) {
        if(operation.type == 25) {
            let message = new Message(operation.message);
            this.receiverID = message.to = (operation.message.to === this.myBot[0]) ? operation.message._from : operation.message.to ;
            Object.assign(message,{ ct: operation.createdTime.toString() });
            this.textMessage(message)
        }
        this.getOprationType(operation);
    }

    command(msg, reply) {
        if(this.messages.text !== null) {
            if(this.messages.text === msg.trim()) {
                if(typeof reply === 'function') {
                    reply();
                    return;
                }
                if(Array.isArray(reply)) {
                    reply.map((v) => {
                        this._sendMessage(this.messages, v);
                    })
                    return;
                }
                return this._sendMessage(this.messages, reply);
            }
        }
    }

    async textMessage(messages) {
        this.messages = messages;
        let payload = (this.messages.text !== null) ? this.messages.text.split(' ').splice(1).join(' ') : '' ;
        let receiver = messages.to;
        let sender = messages.from;

        this.command('help', ['╭───────────────\n│╭──────────────\n│├• sᴇɴᴅ ʙʏ : sᴀмuᴅʀᴀ\n│├• sᴀмuᴅʀᴀ__ʙoтs\n│╰──────────────\n├──•〔 coмᴇɴ נs 〕\n│╭──────────────\n│├─•  ʙʏᴘᴀss :\n││( 𝟏 )• ԍʀouᴘʟιsт\n││( 𝟐 )• sᴘ\n│├─•  ʀᴇsᴘoɴ\n││( 𝟏 )• мᴇ\n││( 𝟐 )• нoʙᴀн(kickall)\n││( 𝟑 )• тᴀмᴘoʟ(cancel kick)\n││ ན ᴄʀ : line://ti/p/~samudrabots.py\n╰───────────────']);
        this.command('sp', this.getSpeed.bind(this));
        this.command('respon', 'JS Siap Pake Bosku');
        this.command('me', this.contact.bind(this));
        this.command('grouplist', this.checkGroup.bind(this));
        this.command('hobah', this.Nook.bind(this));
        this.command('tampol', this.Samudrabotsgans.bind(this));
        this.command('tampol', this.Ngentot.bind(this));

    }

}

module.exports = LINE;
